import type { CSSProperties } from "react";
import type { ThemeTokensV1 } from "./host";
export declare function themeStyle(theme: ThemeTokensV1): CSSProperties;
