export interface ListProjectsRequest {
}
export interface GetProjectRequest {
    id: string;
}
export interface SourceRef {
    id: string;
    locator: string;
    sha256: string;
    expected_sha256: string;
    source_time: string;
    observed_at: string;
    authority: string;
    state: string;
}
export interface Evidence {
    id: string;
    kind: string;
    scope: string;
    result: string;
    candidate: string;
    runtime_producer: string;
    docs_producer: string;
    source_id: string;
    exclusions: string[];
}
export interface CI {
    head: string;
    run_id: string;
    status: string;
    conclusion: string;
    source_id: string;
    reported_jobs: string;
    authority: string;
}
export interface Environment {
    id: string;
    urls: string[];
    desired_artifact: string;
    observed_artifact: string;
    health: string;
    health_observed_at: string;
    source_id: string;
    tls_supplied_ca: string;
    system_trust: string;
    external_dns: string;
}
export interface Allocation {
    id: string;
    candidate: string;
    execution_release: string;
    cleanup_gate: string;
    cleanup_command_exit: string;
    deadline: string;
    source_id: string;
    authority: string;
}
export interface Owner {
    role: string;
    thread_link: string;
    state: string;
    source_id: string;
}
export interface Project {
    id: string;
    name: string;
    stage: string;
    coordination_summary: string;
    source_id: string;
    owner: Owner | null;
    blocker: string;
    next_action: string;
    candidate: string;
    evidence: Evidence[];
    ci: CI[];
    environments: Environment[];
    allocations: Allocation[];
    state: string;
}
export interface Portfolio {
    schema_version: string;
    observed_at: string;
    source_time: string;
    projects: Project[];
    sources: SourceRef[];
    diagnostics: string[];
    persistence: string;
}
export declare const dtoShape: {
    readonly ListProjectsRequest: {};
    readonly GetProjectRequest: {
        readonly id: readonly ["string", false, false];
    };
    readonly SourceRef: {
        readonly id: readonly ["string", false, false];
        readonly locator: readonly ["string", false, false];
        readonly sha256: readonly ["string", false, false];
        readonly expected_sha256: readonly ["string", false, false];
        readonly source_time: readonly ["string", false, false];
        readonly observed_at: readonly ["string", false, false];
        readonly authority: readonly ["string", false, false];
        readonly state: readonly ["string", false, false];
    };
    readonly Evidence: {
        readonly id: readonly ["string", false, false];
        readonly kind: readonly ["string", false, false];
        readonly scope: readonly ["string", false, false];
        readonly result: readonly ["string", false, false];
        readonly candidate: readonly ["string", false, false];
        readonly runtime_producer: readonly ["string", false, false];
        readonly docs_producer: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
        readonly exclusions: readonly ["string", true, false];
    };
    readonly CI: {
        readonly head: readonly ["string", false, false];
        readonly run_id: readonly ["string", false, false];
        readonly status: readonly ["string", false, false];
        readonly conclusion: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
        readonly reported_jobs: readonly ["string", false, false];
        readonly authority: readonly ["string", false, false];
    };
    readonly Environment: {
        readonly id: readonly ["string", false, false];
        readonly urls: readonly ["string", true, false];
        readonly desired_artifact: readonly ["string", false, false];
        readonly observed_artifact: readonly ["string", false, false];
        readonly health: readonly ["string", false, false];
        readonly health_observed_at: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
        readonly tls_supplied_ca: readonly ["string", false, false];
        readonly system_trust: readonly ["string", false, false];
        readonly external_dns: readonly ["string", false, false];
    };
    readonly Allocation: {
        readonly id: readonly ["string", false, false];
        readonly candidate: readonly ["string", false, false];
        readonly execution_release: readonly ["string", false, false];
        readonly cleanup_gate: readonly ["string", false, false];
        readonly cleanup_command_exit: readonly ["string", false, false];
        readonly deadline: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
        readonly authority: readonly ["string", false, false];
    };
    readonly Owner: {
        readonly role: readonly ["string", false, false];
        readonly thread_link: readonly ["string", false, false];
        readonly state: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
    };
    readonly Project: {
        readonly id: readonly ["string", false, false];
        readonly name: readonly ["string", false, false];
        readonly stage: readonly ["string", false, false];
        readonly coordination_summary: readonly ["string", false, false];
        readonly source_id: readonly ["string", false, false];
        readonly owner: readonly ["Owner", false, true];
        readonly blocker: readonly ["string", false, false];
        readonly next_action: readonly ["string", false, false];
        readonly candidate: readonly ["string", false, false];
        readonly evidence: readonly ["Evidence", true, false];
        readonly ci: readonly ["CI", true, false];
        readonly environments: readonly ["Environment", true, false];
        readonly allocations: readonly ["Allocation", true, false];
        readonly state: readonly ["string", false, false];
    };
    readonly Portfolio: {
        readonly schema_version: readonly ["string", false, false];
        readonly observed_at: readonly ["string", false, false];
        readonly source_time: readonly ["string", false, false];
        readonly projects: readonly ["Project", true, false];
        readonly sources: readonly ["SourceRef", true, false];
        readonly diagnostics: readonly ["string", true, false];
        readonly persistence: readonly ["string", false, false];
    };
};
