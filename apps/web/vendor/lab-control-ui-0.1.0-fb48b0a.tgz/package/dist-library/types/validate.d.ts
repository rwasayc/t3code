import type { Portfolio } from "./generated";
import type { HostAdapterV1, PortfolioReadV1 } from "./host";
export declare const threadLink: RegExp;
export declare function validatePortfolio(value: unknown): Portfolio;
export declare function validateRead(value: unknown, host: HostAdapterV1): PortfolioReadV1;
export declare function bindingKey(host: HostAdapterV1): string;
