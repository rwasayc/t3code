import type { Portfolio } from "./generated";
export interface PortfolioReadV1 {
    readonly apiVersion: "1";
    readonly backendInstanceId: string;
    readonly snapshotRevision: string;
    readonly portfolio: Portfolio;
}
export interface HostBindingV1 {
    readonly t3EnvironmentId: string | null;
    readonly backendInstanceId: string;
    readonly bindingRevision: string;
    readonly apiVersion: "1";
}
export interface ThemeTokensV1 {
    readonly mode: "light" | "dark";
    readonly background: string;
    readonly surface: string;
    readonly foreground: string;
    readonly muted: string;
    readonly border: string;
    readonly accent: string;
    readonly success: string;
    readonly danger: string;
}
/** Narrow typed transport and navigation. No arbitrary URL/header/command bridge. */
export interface HostAdapterV1 {
    readonly contractVersion: "1";
    readonly kind: "standalone" | "t3";
    readonly binding: HostBindingV1;
    readonly theme: ThemeTokensV1;
    readonly readPortfolio: (signal: AbortSignal) => Promise<PortfolioReadV1>;
    readonly openThread?: (link: string) => void;
}
