import type { HostAdapterV1 } from "./host";
export declare function connectStandalone(signal: AbortSignal): Promise<HostAdapterV1>;
