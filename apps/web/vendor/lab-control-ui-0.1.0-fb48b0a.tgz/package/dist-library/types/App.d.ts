import type { HostAdapterV1 } from "./host";
export declare function App({ host }: {
    host: HostAdapterV1;
}): import("react/jsx-runtime").JSX.Element;
