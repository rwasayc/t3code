import type { HostAdapterV1, PortfolioReadV1 } from "./host";
/** One bounded read. Cleanup/binding change invalidates even uncancellable success. */
export declare function beginPortfolioRead(host: HostAdapterV1, currentBinding: () => string, success: (value: PortfolioReadV1) => void, failure: () => void): () => void;
