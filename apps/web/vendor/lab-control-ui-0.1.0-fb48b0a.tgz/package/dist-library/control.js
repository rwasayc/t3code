import { useEffect as e, useRef as t, useState as n } from "react";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
// src/validate.ts
var o = {
	ListProjectsRequest: {},
	GetProjectRequest: { id: [
		"string",
		!1,
		!1
	] },
	SourceRef: {
		id: [
			"string",
			!1,
			!1
		],
		locator: [
			"string",
			!1,
			!1
		],
		sha256: [
			"string",
			!1,
			!1
		],
		expected_sha256: [
			"string",
			!1,
			!1
		],
		source_time: [
			"string",
			!1,
			!1
		],
		observed_at: [
			"string",
			!1,
			!1
		],
		authority: [
			"string",
			!1,
			!1
		],
		state: [
			"string",
			!1,
			!1
		]
	},
	Evidence: {
		id: [
			"string",
			!1,
			!1
		],
		kind: [
			"string",
			!1,
			!1
		],
		scope: [
			"string",
			!1,
			!1
		],
		result: [
			"string",
			!1,
			!1
		],
		candidate: [
			"string",
			!1,
			!1
		],
		runtime_producer: [
			"string",
			!1,
			!1
		],
		docs_producer: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		],
		exclusions: [
			"string",
			!0,
			!1
		]
	},
	CI: {
		head: [
			"string",
			!1,
			!1
		],
		run_id: [
			"string",
			!1,
			!1
		],
		status: [
			"string",
			!1,
			!1
		],
		conclusion: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		],
		reported_jobs: [
			"string",
			!1,
			!1
		],
		authority: [
			"string",
			!1,
			!1
		]
	},
	Environment: {
		id: [
			"string",
			!1,
			!1
		],
		urls: [
			"string",
			!0,
			!1
		],
		desired_artifact: [
			"string",
			!1,
			!1
		],
		observed_artifact: [
			"string",
			!1,
			!1
		],
		health: [
			"string",
			!1,
			!1
		],
		health_observed_at: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		],
		tls_supplied_ca: [
			"string",
			!1,
			!1
		],
		system_trust: [
			"string",
			!1,
			!1
		],
		external_dns: [
			"string",
			!1,
			!1
		]
	},
	Allocation: {
		id: [
			"string",
			!1,
			!1
		],
		candidate: [
			"string",
			!1,
			!1
		],
		execution_release: [
			"string",
			!1,
			!1
		],
		cleanup_gate: [
			"string",
			!1,
			!1
		],
		cleanup_command_exit: [
			"string",
			!1,
			!1
		],
		deadline: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		],
		authority: [
			"string",
			!1,
			!1
		]
	},
	Owner: {
		role: [
			"string",
			!1,
			!1
		],
		thread_link: [
			"string",
			!1,
			!1
		],
		state: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		]
	},
	Project: {
		id: [
			"string",
			!1,
			!1
		],
		name: [
			"string",
			!1,
			!1
		],
		stage: [
			"string",
			!1,
			!1
		],
		coordination_summary: [
			"string",
			!1,
			!1
		],
		source_id: [
			"string",
			!1,
			!1
		],
		owner: [
			"Owner",
			!1,
			!0
		],
		blocker: [
			"string",
			!1,
			!1
		],
		next_action: [
			"string",
			!1,
			!1
		],
		candidate: [
			"string",
			!1,
			!1
		],
		evidence: [
			"Evidence",
			!0,
			!1
		],
		ci: [
			"CI",
			!0,
			!1
		],
		environments: [
			"Environment",
			!0,
			!1
		],
		allocations: [
			"Allocation",
			!0,
			!1
		],
		state: [
			"string",
			!1,
			!1
		]
	},
	Portfolio: {
		schema_version: [
			"string",
			!1,
			!1
		],
		observed_at: [
			"string",
			!1,
			!1
		],
		source_time: [
			"string",
			!1,
			!1
		],
		projects: [
			"Project",
			!0,
			!1
		],
		sources: [
			"SourceRef",
			!0,
			!1
		],
		diagnostics: [
			"string",
			!0,
			!1
		],
		persistence: [
			"string",
			!1,
			!1
		]
	}
}, s = {
	"Portfolio.projects": 100,
	"Portfolio.sources": 64,
	"Portfolio.diagnostics": 128,
	"Project.evidence": 64,
	"Project.ci": 16,
	"Project.environments": 16,
	"Project.allocations": 32,
	"Environment.urls": 8,
	"Evidence.exclusions": 32
}, c = /^[A-Za-z0-9_-]{1,64}$/, l = /^<t3-thread:\/\/v2\/[A-Za-z0-9-]+\/[A-Za-z0-9:-]+>$/;
function u(e, t, n = 0) {
	if (n > 6) return !1;
	if (e === "string") return typeof t == "string" && t.length <= 2048 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(t);
	if (e === "number") return typeof t == "number" && Number.isSafeInteger(t);
	if (!t || typeof t != "object" || Array.isArray(t)) return !1;
	let r = t, i = o[e];
	if (!i || Object.keys(r).some((e) => !Object.hasOwn(i, e))) return !1;
	for (let [t, [a, o, c]] of Object.entries(i)) {
		let i = r[t];
		if (!(i === null && c)) {
			if (o) {
				if (!Array.isArray(i) || i.length > (s[e + "." + t] ?? 64) || !i.every((e) => u(a, e, n + 1))) return !1;
			} else if (!u(a, i, n + 1)) return !1;
		}
	}
	if (e === "Owner" && r.thread_link !== "" && !l.test(String(r.thread_link)) || e === "Environment" && !r.urls.every((e) => /^https:\/\/(auth|console|skills|data|memory)\.lab\.localhost$/.test(e))) return !1;
	if (e === "Portfolio") {
		let e = r.projects.map((e) => e.id);
		if (new Set(e).size !== e.length) return !1;
	}
	return !0;
}
function d(e) {
	if (!u("Portfolio", e) || e.schema_version !== "1") throw Error("portfolio_schema_mismatch");
	return e;
}
function f(e, t) {
	if (!e || typeof e != "object") throw Error("read_schema_mismatch");
	let n = e;
	if (t.contractVersion !== "1" || t.binding.apiVersion !== "1" || n.apiVersion !== "1" || !c.test(t.binding.backendInstanceId) || n.backendInstanceId !== t.binding.backendInstanceId || !/^\d{1,20}$/.test(n.snapshotRevision) || !t.binding.bindingRevision || t.binding.bindingRevision.length > 64 || t.kind === "t3" && (typeof t.binding.t3EnvironmentId != "string" || t.binding.t3EnvironmentId.length > 128 || !t.binding.t3EnvironmentId || t.binding.backendInstanceId === "preview-unbound") || t.kind === "standalone" && t.binding.t3EnvironmentId !== null) throw Error("instance_or_binding_mismatch");
	return d(n.portfolio), n;
}
function p(e) {
	return JSON.stringify([
		e.binding.t3EnvironmentId,
		e.binding.backendInstanceId,
		e.binding.bindingRevision,
		e.binding.apiVersion
	]);
}
// src/request.ts
function m(e, t, n, r) {
	let i = p(e), a = new AbortController(), o = !0, s = () => o && !a.signal.aborted && t() === i && p(e) === i, c = setTimeout(() => {
		o && t() === i && r(), o = !1, a.abort();
	}, 5e3);
	return Promise.resolve().then(() => {
		if (!s()) throw Error("read_disposed");
		return e.readPortfolio(a.signal);
	}).then((t) => {
		if (!s()) return;
		let r = f(t, e);
		s() && n(r);
	}).catch(() => {
		s() && r();
	}).finally(() => clearTimeout(c)), () => {
		o = !1, a.abort(), clearTimeout(c);
	};
}
// src/theme.ts
function h(e) {
	let t = /^(?:#[0-9a-fA-F]{3,8}|(?:rgb|rgba|hsl|hsla|oklch)\([\d.,% /-]+\)|var\(--[a-zA-Z0-9-]+\))$/;
	if (!["light", "dark"].includes(e.mode) || !Object.entries(e).every(([e, n]) => e === "mode" || typeof n == "string" && n.length <= 128 && t.test(n))) throw Error("theme_contract_invalid");
	return {
		"--lc-bg": e.background,
		"--lc-card": e.surface,
		"--lc-fg": e.foreground,
		"--lc-muted": e.muted,
		"--lc-line": e.border,
		"--lc-accent": e.accent,
		"--lc-success": e.success,
		"--lc-danger": e.danger,
		colorScheme: e.mode
	};
}
// src/App.tsx
var g = {
	authova: "authova",
	datadock: "datadock",
	converrail: "converrail",
	monetrace: "monetrace",
	stowleaf: "stowleaf"
};
function _(e, t) {
	return g[e] && /^[1-9][0-9]{0,19}$/.test(t) ? `https://github.com/carvebloom/${g[e]}/actions/runs/${t}` : null;
}
var v = (e) => e || "unknown", y = (e) => [
	"FAIL",
	"failure",
	"RESOURCE_LIMIT"
].includes(e) ? "bad" : ["PASS", "success"].includes(e) ? "good" : "muted";
function b({ project: e, data: t, host: n }) {
	let o = /* @__PURE__ */ new Set([
		e.source_id,
		e.owner?.source_id ?? "",
		...e.evidence.map((e) => e.source_id),
		...e.ci.map((e) => e.source_id),
		...e.environments.map((e) => e.source_id),
		...e.allocations.map((e) => e.source_id)
	]);
	return /* @__PURE__ */ a(r, { children: [
		/* @__PURE__ */ a("header", { children: [/* @__PURE__ */ i("h2", { children: e.name }), /* @__PURE__ */ i("span", {
			className: "tag",
			children: e.state
		})] }),
		/* @__PURE__ */ a("dl", { children: [
			/* @__PURE__ */ i("dt", { children: "阶段" }),
			/* @__PURE__ */ i("dd", { children: e.stage }),
			/* @__PURE__ */ i("dt", { children: "当前卡点" }),
			/* @__PURE__ */ i("dd", { children: e.blocker }),
			/* @__PURE__ */ i("dt", { children: "下一步" }),
			/* @__PURE__ */ i("dd", { children: e.next_action }),
			/* @__PURE__ */ i("dt", { children: "当前候选" }),
			/* @__PURE__ */ i("dd", { children: /* @__PURE__ */ i("code", { children: v(e.candidate) }) }),
			/* @__PURE__ */ i("dt", { children: "责任" }),
			/* @__PURE__ */ a("dd", { children: [
				e.owner?.role,
				" · ",
				e.owner?.state,
				e.owner?.thread_link && /* @__PURE__ */ a(r, { children: [
					/* @__PURE__ */ i("br", {}),
					/* @__PURE__ */ i("code", { children: e.owner.thread_link }),
					n.openThread && l.test(e.owner.thread_link) && /* @__PURE__ */ i("button", {
						onClick: () => n.openThread?.(e.owner.thread_link),
						children: "打开线程"
					})
				] })
			] })
		] }),
		/* @__PURE__ */ i("h3", { children: "精确 CI（来源审查，不是本次远端刷新）" }),
		e.ci.length === 0 ? /* @__PURE__ */ i("p", {
			className: "muted",
			children: "unknown · 尚无精确CI来源"
		}) : e.ci.map((t, n) => /* @__PURE__ */ a("article", { children: [
			/* @__PURE__ */ i("b", {
				className: y(t.conclusion),
				children: v(t.conclusion)
			}),
			" · run ",
			_(e.id, t.run_id) ? /* @__PURE__ */ a("a", {
				href: _(e.id, t.run_id),
				target: "_blank",
				rel: "noreferrer",
				children: [t.run_id, " ↗"]
			}) : v(t.run_id),
			/* @__PURE__ */ i("br", {}),
			/* @__PURE__ */ a("code", { children: ["head ", v(t.head)] }),
			/* @__PURE__ */ i("small", { children: t.authority })
		] }, n)),
		/* @__PURE__ */ i("h3", { children: "有限验收与制品来源" }),
		e.evidence.length === 0 ? /* @__PURE__ */ i("p", {
			className: "muted",
			children: "unknown · 不从组织摘要推断已验收"
		}) : e.evidence.map((e) => /* @__PURE__ */ a("article", { children: [
			/* @__PURE__ */ i("b", {
				className: y(e.result),
				children: e.result
			}),
			" · ",
			e.scope,
			/* @__PURE__ */ a("div", {
				className: "producers",
				children: [
					/* @__PURE__ */ a("span", { children: ["candidate ", /* @__PURE__ */ i("code", { children: v(e.candidate) })] }),
					/* @__PURE__ */ a("span", { children: ["runtime ", /* @__PURE__ */ i("code", { children: v(e.runtime_producer) })] }),
					/* @__PURE__ */ a("span", { children: ["docs ", /* @__PURE__ */ i("code", { children: v(e.docs_producer) })] })
				]
			}),
			/* @__PURE__ */ i("small", { children: e.exclusions.join(" · ") })
		] }, e.id)),
		/* @__PURE__ */ i("h3", { children: "测试环境" }),
		e.environments.length === 0 ? /* @__PURE__ */ i("p", {
			className: "muted",
			children: "未登记 Lab 测试部署 · 不代表服务不存在"
		}) : e.environments.map((e) => /* @__PURE__ */ a("article", { children: [
			/* @__PURE__ */ i("b", { children: e.id }),
			" · 健康 ",
			e.health,
			/* @__PURE__ */ i("div", { children: e.urls.map((e) => /* @__PURE__ */ a("a", {
				href: e,
				target: "_blank",
				rel: "noreferrer",
				children: [e, " ↗ "]
			}, e)) }),
			/* @__PURE__ */ a("small", { children: [
				"期望 ",
				e.desired_artifact,
				" / 实际 ",
				e.observed_artifact,
				" / 观测 ",
				v(e.health_observed_at)
			] }),
			/* @__PURE__ */ a("small", { children: [
				"CA校验 ",
				e.tls_supplied_ca,
				" · 系统信任 ",
				e.system_trust,
				" · 外部DNS ",
				e.external_dns
			] })
		] }, e.id)),
		/* @__PURE__ */ i("h3", { children: "窗口历史（不代表当前全局资源槽）" }),
		e.allocations.length === 0 ? /* @__PURE__ */ i("p", {
			className: "muted",
			children: "unknown · 无本切片资源证据"
		}) : e.allocations.map((e) => /* @__PURE__ */ a("article", { children: [/* @__PURE__ */ i("b", { children: e.id }), /* @__PURE__ */ a("p", { children: [
			"执行资源释放：",
			e.execution_release,
			" · cleanup gate：",
			/* @__PURE__ */ i("b", {
				className: y(e.cleanup_gate),
				children: e.cleanup_gate
			}),
			" · cleanup exit：",
			e.cleanup_command_exit
		] })] }, e.id)),
		/* @__PURE__ */ i("h3", { children: "来源与适用性" }),
		t.sources.filter((e) => o.has(e.id)).map((e) => /* @__PURE__ */ a("article", { children: [
			/* @__PURE__ */ i("b", {
				className: e.state.includes("conflict") ? "bad" : "muted",
				children: e.state
			}),
			/* @__PURE__ */ i("code", { children: e.locator }),
			/* @__PURE__ */ a("small", { children: [
				"SHA256 ",
				e.sha256,
				/* @__PURE__ */ i("br", {}),
				"源时间 ",
				v(e.source_time),
				" / 导入 ",
				e.observed_at,
				/* @__PURE__ */ i("br", {}),
				e.authority
			] })
		] }, e.id))
	] });
}
function x({ host: o }) {
	let [s, c] = n(null), [l, u] = n("nookamble"), [d, f] = n(""), [g, _] = n(""), [v, y] = n(0), [x, S] = n(!0), C = p(o), w = t(C);
	w.current = C;
	let [T, E] = n("");
	e(() => (S(!0), _(""), m(o, () => w.current, (e) => {
		c(e.portfolio), E(C), S(!1);
	}, () => {
		_("读取不可用；保留同一绑定的旧观测，不代表当前实时状态。"), S(!1);
	})), [
		C,
		o.readPortfolio,
		v
	]);
	let D = T === C ? s : null, O = D?.projects.find((e) => e.id === l);
	return /* @__PURE__ */ a("main", {
		className: "lc-control",
		style: h(o.theme),
		children: [
			/* @__PURE__ */ a("header", {
				className: "top",
				children: [/* @__PURE__ */ a("div", { children: [
					/* @__PURE__ */ a("span", {
						className: "muted",
						children: [
							o.kind,
							" / ",
							o.binding.backendInstanceId,
							" / ",
							o.binding.t3EnvironmentId ?? "本地只读"
						]
					}),
					/* @__PURE__ */ i("h1", { children: "项目进度" }),
					/* @__PURE__ */ i("p", { children: "项目动作只读 · 无自动派发、重启或发布" })
				] }), /* @__PURE__ */ i("button", {
					disabled: x,
					onClick: () => y((e) => e + 1),
					children: "重新读取后端快照"
				})]
			}),
			g && /* @__PURE__ */ i("p", {
				role: "alert",
				className: "bad",
				children: g
			}),
			D && /* @__PURE__ */ a(r, { children: [
				/* @__PURE__ */ a("p", {
					className: "notice",
					children: [
						D.projects.length,
						" 个项目 · 导入 ",
						D.observed_at,
						" · 根交接 ",
						D.source_time,
						/* @__PURE__ */ i("br", {}),
						D.persistence === "ephemeral_preview_not_durable" ? "临时内存预览；不代表持久化。" : "读取已提交MySQL投影；不代表各项目当前健康。",
						" 刷新只读取后端读模型，不触发上游探测。"
					]
				}),
				/* @__PURE__ */ a("div", {
					className: "layout",
					children: [/* @__PURE__ */ a("nav", {
						"aria-label": "项目",
						children: [/* @__PURE__ */ a("label", { children: ["筛选项目", /* @__PURE__ */ i("input", {
							value: d,
							onChange: (e) => f(e.target.value),
							placeholder: "名称或卡点"
						})] }), D.projects.filter((e) => (e.name + e.blocker).toLowerCase().includes(d.toLowerCase())).map((e) => /* @__PURE__ */ a("button", {
							"aria-pressed": e.id === l,
							onClick: () => u(e.id),
							children: [
								/* @__PURE__ */ i("b", { children: e.name }),
								/* @__PURE__ */ i("small", { children: e.stage }),
								/* @__PURE__ */ a("small", {
									className: "muted",
									children: ["卡点：", e.blocker]
								})
							]
						}, e.id))]
					}), /* @__PURE__ */ i("section", {
						"aria-label": "项目详情",
						children: O ? /* @__PURE__ */ i(b, {
							project: O,
							data: D,
							host: o
						}) : /* @__PURE__ */ i("p", { children: "选择项目" })
					})]
				}),
				/* @__PURE__ */ a("details", { children: [/* @__PURE__ */ a("summary", { children: [
					"导入诊断（",
					D.diagnostics.length,
					"）"
				] }), D.diagnostics.map((e, t) => /* @__PURE__ */ i("p", { children: e }, t))] })
			] }),
			!D && /* @__PURE__ */ i("p", {
				role: "status",
				children: x ? "读取真实来源…" : "后端不可用；不显示假数据。"
			})
		]
	});
}
export { x as App, d as validatePortfolio, f as validateRead };
